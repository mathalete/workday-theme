<?php
/**
 * Content for displaying read more link and comment link.
 *
 * @package Checathlon
 */
?>

<div class="entry-comment grid-same-line">
	<?php
		checathlon_read_more_link();
		checathlon_comments_popup_link();
	?>
</div><!-- .entry-comment -->
