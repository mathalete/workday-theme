/**
 * File navigation.js.
 *
 * Handles toggling the navigation menu for small screens and enables TAB key
 * navigation support for dropdown menus.
 */
( function() {
	var html, body, container, button, menu, menuWrapper, links, subMenus, i, len, focusableElements, firstFocusableElement, lastFocusableElement;

	container = document.getElementById( 'site-navigation' );
	if ( ! container ) {
		return;
	}

	button = document.getElementById( 'menu-toggle' );
	if ( 'undefined' === typeof button ) {
		return;
	}

	// Set vars.
	html        = document.getElementsByTagName( 'html' )[0];
	body        = document.getElementsByTagName( 'body' )[0];
	menu        = container.getElementsByTagName( 'ul' )[0];
	menuWrapper = document.getElementById( 'main-navigation-wrapper' );

	// Hide menu toggle button if menu is empty and return early.
	if ( 'undefined' === typeof menu ) {
		button.style.display = 'none';
		return;
	}

	if ( -1 === menu.className.indexOf( 'nav-menu' ) ) {
		menu.className += ' nav-menu';
	}

	button.onclick = function() {
		if ( -1 !== container.className.indexOf( 'toggled' ) ) {
			closeMenu(); // Close menu.
		} else {
			html.className      += ' disable-scroll';
			body.className      += ' main-navigation-open';
			container.className += ' toggled';
			button.className    += ' toggled';
			button.setAttribute( 'aria-expanded', 'true' );

			// Set focusable elements inside main navigation.
			focusableElements     = container.querySelectorAll( ['a[href]', 'area[href]', 'input:not([disabled])', 'select:not([disabled])', 'textarea:not([disabled])', 'button:not([disabled])', 'iframe', 'object', 'embed', '[contenteditable]', '[tabindex]:not([tabindex^="-"])'] );
			firstFocusableElement = focusableElements[0];
			lastFocusableElement  = focusableElements[focusableElements.length - 1];

			// Redirect last Tab to first focusable element.
			lastFocusableElement.addEventListener( 'keydown', function ( e ) {
				if ( ( e.keyCode === 9 && ! e.shiftKey ) ) {
					e.preventDefault();
					button.focus(); // Set focus on first element - that's actually close menu button.
				}
			});

			// Redirect first Shift+Tab to toggle button element.
			firstFocusableElement.addEventListener( 'keydown', function ( e ) {
				if ( ( e.keyCode === 9 && e.shiftKey ) ) {
					e.preventDefault();
					button.focus(); // Set focus on last element.
				}
			});

			// Redirect Shift+Tab from the toggle button to last focusable element.
			button.addEventListener( 'keydown', function ( e ) {
				if ( ( e.keyCode === 9 && e.shiftKey ) ) {
					e.preventDefault();
					lastFocusableElement.focus(); // Set focus on last element.
				}
			});
		}
	};

	// Close menu using Esc key.
	document.addEventListener( 'keyup', function( event ) {

		if ( event.keyCode == 27 ) {
			if ( -1 !== container.className.indexOf( 'toggled' ) ) {
				closeMenu(); // Close menu.
			}
		}

	});

	// Close menu clicking menu wrapper area.
	menuWrapper.onclick = function( e ) {
		if ( e.target == menuWrapper && -1 !== container.className.indexOf( 'toggled' ) ) {
			closeMenu(); // Close menu.
		}
	};

	// Close menu function.
	function closeMenu() {
		html.className      = html.className.replace( ' disable-scroll', '' );
		body.className      = body.className.replace( ' main-navigation-open', '' );
		container.className = container.className.replace( ' toggled', '' );
		button.className    = button.className.replace( ' toggled', '' );
		button.setAttribute( 'aria-expanded', 'false' );
		button.focus();
	}

	// Get all the link elements within the menu.
	links    = menu.getElementsByTagName( 'a' );
	subMenus = menu.getElementsByTagName( 'ul' );

	// Each time a menu link is focused or blurred, toggle focus.
	for ( i = 0, len = links.length; i < len; i++ ) {
		links[i].addEventListener( 'focus', toggleFocus, true );
		links[i].addEventListener( 'blur', toggleFocus, true );
	}

	/**
	 * Sets or removes .focus class on an element.
	 */
	function toggleFocus() {
		var self = this;

		// Move up through the ancestors of the current link until we hit .nav-menu.
		while ( -1 === self.className.indexOf( 'nav-menu' ) ) {

			// On li elements toggle the class .focus.
			if ( 'li' === self.tagName.toLowerCase() ) {
				if ( -1 !== self.className.indexOf( 'focus' ) ) {
					self.className = self.className.replace( ' focus', '' );
				} else {
					self.className += ' focus';
				}
			}

			self = self.parentElement;
		}
	}
	
} )();

/**
 * Skip link focus fix.
 *
 * Helps with accessibility for keyboard only users.
 *
 * Learn more: https://git.io/vWdr2
 */
( function() {
	var isIe = /(trident|msie)/i.test( navigator.userAgent );

	if ( isIe && document.getElementById && window.addEventListener ) {
		window.addEventListener( 'hashchange', function() {
			var id = location.hash.substring( 1 ),
				element;

			if ( ! ( /^[A-z0-9_-]+$/.test( id ) ) ) {
				return;
			}

			element = document.getElementById( id );

			if ( element ) {
				if ( ! ( /^(?:a|select|input|button|textarea)$/i.test( element.tagName ) ) ) {
					element.tabIndex = -1;
				}

				element.focus();
			}
		}, false );
	}

	
	
})();