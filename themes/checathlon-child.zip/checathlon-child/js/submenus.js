/*!
 * submenus.js
 *
 * This script does the following -
 * 
 *  - adds role="list" to the parent navigation <ul> and subsequent chlid <ul>
 *  - constructs and injects buttons as siblings to each submenu link
 *  - clicking that button will toggle the display of the corresponding submenu
 *  - clicking one submenu button will close any other submenus that are open
 *  - pressing the escape key when focus is inside a submenu will close it
 *  - pressing tab on the last link in a submenu will close that submenu
 *  - pressing shift/tab on the first link in a submenu will close that submenu
 * 
 *  Caveats
 *  - As per the Checathlon theme, submenus must not be more than 1 level deep
 */

(function () {
    var subMenus, menu;
  
    container = document.getElementById("site-navigation");
    menu = container.getElementsByTagName("ul")[0];
    subMenus = menu.getElementsByTagName("ul");
  
    // For webkit add role list
    menu.setAttribute("role", "list");

    // Sub menus

    if ( ! subMenus ) {
      return;
    }

    for (i = 0, len = subMenus.length; i < len; i++) {
      subMenus[i].setAttribute("role", "list");
    }
  
    for (i = 0, len = subMenus.length; i < len; i++) {
      var subMenuParentLink = subMenus[i].parentNode.firstElementChild;
      var subMenuParentLinkText =
        subMenus[i].parentNode.firstElementChild.innerHTML;
  
      // Set up IDs
      subMenuParentLink.setAttribute("id", "subMenu-parent-" + i);
      subMenus[i].setAttribute("id", "subMenu-" + i);
  
      // Hide the submenus on page load
      subMenus[i].className += " hide";
  
      // Insert a button with all required attributes
      var subMenuToggleButton = document.createElement("button");
      subMenuToggleButton.setAttribute("type", "button");
      subMenuToggleButton.setAttribute("id", "subMenu-toggle-" + i);
      subMenuToggleButton.setAttribute("data-toggle", "dropdown");
      subMenuToggleButton.setAttribute("data-target", "#subMenu-" + i);
      subMenuToggleButton.setAttribute("aria-expanded", "false");
      subMenuToggleButton.setAttribute("aria-controls", "subMenu-" + i);
      subMenuToggleButton.classList.add("subMenu-toggle");
      var insertSubMenuButton = subMenus[i].parentNode;
      insertSubMenuButton.insertBefore(subMenuToggleButton, subMenus[i]);
  
      // Insert SVG
      subMenuToggleButton.innerHTML =
        " <svg aria-hidden='true' focusable='false' xmlns='http://www.w3.org/2000/svg' fill='current-color' width='1em' height='1em' viewBox='0 0 960 560'><defs/><path d='M480 344.181L268.869 131.889c-15.756-15.859-41.3-15.859-57.054 0-15.754 15.857-15.754 41.57 0 57.431l237.632 238.937c8.395 8.451 19.562 12.254 30.553 11.698 10.993.556 22.159-3.247 30.555-11.698L748.186 189.32c15.756-15.86 15.756-41.571 0-57.431s-41.299-15.859-57.051 0L480 344.181z'/></svg>";

      // Give the button a name derived from link text
      subMenuToggleButton.setAttribute(
        "aria-label",
        subMenuParentLinkText + " submenu"
      );

    } // construct buttons
  
    // Button behaviour
  
    // Get all toggle buttons 
    var menuToggleButtons = document.querySelectorAll("[data-toggle=dropdown]");
  
    for (var i = 0, s = menuToggleButtons.length; i < s; i++) {
      var thisToggleButton = menuToggleButtons[i];
  
      thisToggleButton.addEventListener("click", function () {
        var isExpanded = this.getAttribute("aria-expanded");
        var thisSubMenu = this.getAttribute("data-target");

        // Toggle class on button to visually indicate state
        this.classList.toggle('expanded');
  
        // Toggle aria-expanded on this button, and toggle class on sibling submenu
        if (isExpanded == "true") {
          this.setAttribute("aria-expanded", "false");
          this.nextElementSibling.classList.add("hide");
        } else {
          this.setAttribute("aria-expanded", "true");
          this.nextElementSibling.classList.remove("hide");
        }
        // aria-expanded
  
        // Toggle class and attribute on siblings
        for (var j = 0, z = menuToggleButtons.length; j < z; j++) {
          if (menuToggleButtons[j] != this) {
            // Set aria-expanded to false on other dropdowns
            menuToggleButtons[j].setAttribute("aria-expanded", "false");
  
            // Get corresponding dropdown menus
            var siblingSubMenus = document.querySelector(
              menuToggleButtons[j].getAttribute("data-target")
            );
  
            // hide other menus that are opened
            siblingSubMenus.classList.add("hide");
          }
        } // for each sibling menuToggleButton
  
        // Get the submenu of the current button
        var thisSubMenu = document.querySelector(
          this.getAttribute("data-target")
        );
  
        // Get the last link of the current menu
        var lastItem = thisSubMenu.lastElementChild;
        var lastLink = lastItem.querySelector("a");
        
        // Get first item of the current list
        var firstItem = thisSubMenu.firstElementChild;
        var firstLink = firstItem.querySelector("a");

        // Pressing tab on the last link in a submenu will close the menu
        lastLink.addEventListener("keydown", function (e) {
           if (e.keyCode === 9 && !e.shiftKey) {
            console.log('Tab close menu');
            thisSubMenu.classList.add("hide");
            thisSubMenu.previousSibling.setAttribute("aria-expanded", "false");
          }
        });
        
        // Pressing shift+tab in the first link in a submenu will close the menu
        firstLink.addEventListener("keydown", function (e) {
           if (e.keyCode === 9 && e.shiftKey) {
            console.log('Shift tab close menu');
            thisSubMenu.classList.add("hide");
            thisSubMenu.previousSibling.setAttribute("aria-expanded", "false");
          }
        });
  
        // Pressing the escape key when focus is in a submenu closes it
        thisSubMenu.addEventListener("keydown", function (e) {
          switch (e.which) {
            case 27:
              e.preventDefault();
              var self = this;
              self.classList.add("hide");
              self.previousSibling.setAttribute("aria-expanded", "false");
  
              setTimeout(function () {
                self.previousSibling.focus();
              }, 350);
              break;
          } //switch
        }); // escape key

       

      }); // thisToggleButton click
    } // for menuToggleButtons
  })(); // function
  
  